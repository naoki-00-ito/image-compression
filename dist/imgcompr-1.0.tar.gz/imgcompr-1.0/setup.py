from setuptools import setup

setup(
    name="imgcompr",
    version='1.0',
    description='画像圧縮ツール',
    author='Ito Naoki',
    author_email='so30.itonaoki@gmail.com',
    url='https://github.com/ItoNaoki/image-compression',
)